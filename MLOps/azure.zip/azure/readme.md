This folder contains datasets and files for Microsoft Azure MLOps Demo.
